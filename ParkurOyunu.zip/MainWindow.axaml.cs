using System;
using System.Collections.Generic;
using System.Globalization;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Input;
using Avalonia.Media;
using Avalonia.Threading;

namespace ParkurOyunu;

public partial class MainWindow : Window
{
    private readonly HashSet<Key> _basiliTuslar = new();
    private readonly DispatcherTimer _oyunDongusu;
    private int _mevcutBolum = 1;
    private int _olumSayisi;
    private bool _oyunBitti;

    private const double Yercekimi = 0.65;
    private const double ZiplamaGucu = -13.5;
    private const double HareketHizi = 5.2;

    public MainWindow()
    {
        InitializeComponent();
        BolumuYukle(_mevcutBolum);

        KeyDown += (_, e) =>
        {
            _basiliTuslar.Add(e.Key);
            if (e.Key == Key.R)
            {
                if (_oyunBitti)
                {
                    _oyunBitti = false;
                    _olumSayisi = 0;
                    _mevcutBolum = 1;
                }
                BolumuYukle(_mevcutBolum);
            }
        };

        KeyUp += (_, e) => _basiliTuslar.Remove(e.Key);

        _oyunDongusu = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(16) };
        _oyunDongusu.Tick += (_, _) => OyunAdimi();
        _oyunDongusu.Start();
    }

    private void BolumuYukle(int bolumNo)
    {
        var bolum = BolumYoneticisi.BolumGetir(bolumNo);
        Sahne.Bolum = bolum;
        Sahne.OyunBittiMi = _oyunBitti;
        Sahne.OlumSayisi = _olumSayisi;
        Sahne.Oyuncu = new Oyuncu
        {
            X = bolum.Baslangic.X,
            Y = bolum.Baslangic.Y
        };
        Sahne.InvalidateVisual();
    }

    private void OyunAdimi()
    {
        if (_oyunBitti) return;

        var oyuncu = Sahne.Oyuncu;
        var bolum = Sahne.Bolum;

        foreach (var hp in bolum.HareketliPlatformlar)
            hp.Guncelle();

        oyuncu.HizX = 0;
        if (_basiliTuslar.Contains(Key.A))
        {
            oyuncu.HizX = -HareketHizi;
            oyuncu.SagaBakiyor = false;
        }
        if (_basiliTuslar.Contains(Key.D))
        {
            oyuncu.HizX = HareketHizi;
            oyuncu.SagaBakiyor = true;
        }

        bool sBasili = _basiliTuslar.Contains(Key.S);
        if (sBasili && !oyuncu.EgiliyorMu)
        {
            oyuncu.Y += oyuncu.NormalYukseklik - oyuncu.EgilmeYukseklik;
            oyuncu.EgiliyorMu = true;
        }
        else if (!sBasili && oyuncu.EgiliyorMu)
        {
            oyuncu.Y -= oyuncu.NormalYukseklik - oyuncu.EgilmeYukseklik;
            oyuncu.EgiliyorMu = false;
            if (PlatformlaCakisiyorMu(oyuncu, bolum))
            {
                oyuncu.Y += oyuncu.NormalYukseklik - oyuncu.EgilmeYukseklik;
                oyuncu.EgiliyorMu = true;
            }
        }

        if ((_basiliTuslar.Contains(Key.W) || _basiliTuslar.Contains(Key.Space)) && oyuncu.YerdeMi)
        {
            oyuncu.HizY = ZiplamaGucu;
            oyuncu.YerdeMi = false;
        }

        oyuncu.X = Math.Clamp(oyuncu.X + oyuncu.HizX, 0, Width - oyuncu.Genislik);
        foreach (var p in TumPlatformlar(bolum))
        {
            if (oyuncu.Alan.Intersects(p.Alan))
            {
                if (oyuncu.HizX > 0) oyuncu.X = p.X - oyuncu.Genislik;
                else if (oyuncu.HizX < 0) oyuncu.X = p.X + p.Genislik;
            }
        }

        oyuncu.HizY += sBasili && !oyuncu.YerdeMi ? Yercekimi * 1.9 : Yercekimi;
        oyuncu.Y += oyuncu.HizY;
        oyuncu.YerdeMi = false;

        foreach (var p in TumPlatformlar(bolum))
        {
            if (oyuncu.Alan.Intersects(p.Alan))
            {
                if (oyuncu.HizY > 0)
                {
                    oyuncu.Y = p.Y - oyuncu.Yukseklik;
                    oyuncu.HizY = 0;
                    oyuncu.YerdeMi = true;

                    if (p is HareketliPlatform hp)
                        oyuncu.X = Math.Clamp(oyuncu.X + hp.SonDeltaX, 0, Width - oyuncu.Genislik);
                }
                else if (oyuncu.HizY < 0)
                {
                    oyuncu.Y = p.Y + p.Yukseklik;
                    oyuncu.HizY = 0;
                }
            }
        }

        if (oyuncu.Y > Height)
        {
            OyuncuYandi();
            return;
        }

        foreach (var t in bolum.Tehlikeler)
        {
            if (oyuncu.Alan.Intersects(t.Alan))
            {
                OyuncuYandi();
                return;
            }
        }

        if (oyuncu.Alan.Intersects(bolum.Portal))
        {
            if (_mevcutBolum < BolumYoneticisi.ToplamBolum)
            {
                _mevcutBolum++;
                BolumuYukle(_mevcutBolum);
            }
            else
            {
                _oyunBitti = true;
                Sahne.OyunBittiMi = true;
            }
        }

        Sahne.InvalidateVisual();
    }

    private void OyuncuYandi()
    {
        _olumSayisi++;
        BolumuYukle(_mevcutBolum);
    }

    private static IEnumerable<Platform> TumPlatformlar(BolumVerisi bolum)
    {
        foreach (var p in bolum.Platformlar) yield return p;
        foreach (var hp in bolum.HareketliPlatformlar) yield return hp;
    }

    private static bool PlatformlaCakisiyorMu(Oyuncu oyuncu, BolumVerisi bolum)
    {
        foreach (var p in TumPlatformlar(bolum))
            if (oyuncu.Alan.Intersects(p.Alan)) return true;
        return false;
    }
}

public class OyunAlani : Control
{
    public Oyuncu Oyuncu { get; set; } = new();
    public BolumVerisi Bolum { get; set; } = new();
    public int OlumSayisi { get; set; }
    public bool OyunBittiMi { get; set; }

    private static readonly IBrush ArkaPlanFircasi = new SolidColorBrush(Color.Parse("#12151E"));
    private static readonly IPen IzgaraKalemi = new Pen(new SolidColorBrush(Color.Parse("#1C2230")), 1);
    private static readonly IBrush PlatformFircasi = new SolidColorBrush(Color.Parse("#334155"));
    private static readonly IBrush PlatformUstFircasi = new SolidColorBrush(Color.Parse("#64748B"));
    private static readonly IBrush HareketliFircasi = new SolidColorBrush(Color.Parse("#0284C7"));
    private static readonly IBrush LavFircasi = new SolidColorBrush(Color.Parse("#EF4444"));
    private static readonly IBrush PortalDisFircasi = new SolidColorBrush(Color.Parse("#10B981"));
    private static readonly IBrush PortalIcFircasi = new SolidColorBrush(Color.Parse("#A7F3D0"));
    private static readonly IBrush OyuncuFircasi = new SolidColorBrush(Color.Parse("#F59E0B"));

    public override void Render(DrawingContext context)
    {
        base.Render(context);
        var ekran = new Rect(0, 0, Bounds.Width, Bounds.Height);
        context.FillRectangle(ArkaPlanFircasi, ekran);

        for (double x = 0; x < Bounds.Width; x += 45)
            context.DrawLine(IzgaraKalemi, new Point(x, 0), new Point(x, Bounds.Height));
        for (double y = 0; y < Bounds.Height; y += 45)
            context.DrawLine(IzgaraKalemi, new Point(0, y), new Point(Bounds.Width, y));

        context.DrawRectangle(PortalDisFircasi, null, Bolum.Portal, 8, 8);
        context.DrawRectangle(PortalIcFircasi, null, Bolum.Portal.Deflate(7), 5, 5);

        foreach (var p in Bolum.Platformlar)
        {
            context.DrawRectangle(PlatformFircasi, null, p.Alan, 4, 4);
            context.FillRectangle(PlatformUstFircasi, new Rect(p.X, p.Y, p.Genislik, 4));
        }

        foreach (var hp in Bolum.HareketliPlatformlar)
        {
            context.DrawRectangle(HareketliFircasi, null, hp.Alan, 4, 4);
            context.FillRectangle(Brushes.LightSkyBlue, new Rect(hp.X, hp.Y, hp.Genislik, 3));
        }

        foreach (var t in Bolum.Tehlikeler)
        {
            if (t.LavMi)
            {
                context.FillRectangle(LavFircasi, t.Alan);
            }
            else
            {
                double adim = 14;
                for (double sx = t.Alan.X; sx < t.Alan.Right - 4; sx += adim)
                {
                    var ucgen = new StreamGeometry();
                    using (var g = ucgen.Open())
                    {
                        g.BeginFigure(new Point(sx, t.Alan.Bottom), true);
                        g.LineTo(new Point(sx + adim / 2, t.Alan.Y));
                        g.LineTo(new Point(sx + adim, t.Alan.Bottom));
                        g.EndFigure(true);
                    }
                    context.DrawGeometry(LavFircasi, null, ucgen);
                }
            }
        }

        context.DrawRectangle(OyuncuFircasi, null, Oyuncu.Alan, 5, 5);
        double gozX = Oyuncu.SagaBakiyor ? Oyuncu.X + 17 : Oyuncu.X + 5;
        context.FillRectangle(Brushes.Black, new Rect(gozX, Oyuncu.Y + 7, 5, 5));

        YaziCiz(context, $"BÖLÜM {Bolum.Numara}/{BolumYoneticisi.ToplamBolum}: {Bolum.Ad}   |   Hata: {OlumSayisi}",
            16, 12, 16, Brushes.White, FontWeight.Bold);
        YaziCiz(context, Bolum.Ipucu, 16, 36, 13, Brushes.LightGray, FontWeight.Normal);
        YaziCiz(context, "[W / SPACE] Zıpla   [A / D] Yön   [S] Eğil / Hızlı İn   [R] Yeniden Başlat",
            16, 56, 12, Brushes.SkyBlue, FontWeight.Normal);

        if (OyunBittiMi)
        {
            context.FillRectangle(new SolidColorBrush(Color.FromArgb(200, 10, 15, 25)), ekran);
            YaziCiz(context, "TEBRİKLER! 10 BÖLÜMÜN TAMAMINI BİTİRDİN!", 210, 220, 22, Brushes.LightGreen, FontWeight.Bold);
            YaziCiz(context, $"Toplam Hata Sayısı: {OlumSayisi}   —   Baştan başlamak için [R] tuşuna bas.",
                235, 260, 15, Brushes.White, FontWeight.Normal);
        }
    }

    private static void YaziCiz(DrawingContext context, string metin, double x, double y,
        double boyut, IBrush renk, FontWeight kalinlik)
    {
        var ft = new FormattedText(metin, CultureInfo.CurrentCulture, FlowDirection.LeftToRight,
            new Typeface("Segoe UI", FontStyle.Normal, kalinlik), boyut, renk);
        context.DrawText(ft, new Point(x, y));
    }
}

public class Oyuncu
{
    public double X { get; set; }
    public double Y { get; set; }
    public double Genislik { get; } = 28;
    public double NormalYukseklik { get; } = 36;
    public double EgilmeYukseklik { get; } = 22;
    public double Yukseklik => EgiliyorMu ? EgilmeYukseklik : NormalYukseklik;

    public double HizX { get; set; }
    public double HizY { get; set; }
    public bool YerdeMi { get; set; }
    public bool EgiliyorMu { get; set; }
    public bool SagaBakiyor { get; set; } = true;

    public Rect Alan => new(X, Y, Genislik, Yukseklik);
}

public class Platform
{
    public double X { get; set; }
    public double Y { get; set; }
    public double Genislik { get; set; }
    public double Yukseklik { get; set; }

    public Platform(double x, double y, double genislik, double yukseklik)
    {
        X = x;
        Y = y;
        Genislik = genislik;
        Yukseklik = yukseklik;
    }

    public Rect Alan => new(X, Y, Genislik, Yukseklik);
}

public class HareketliPlatform : Platform
{
    public double MinX { get; }
    public double MaxX { get; }
    public double MinY { get; }
    public double MaxY { get; }
    public double HizX { get; set; }
    public double HizY { get; set; }
    public double SonDeltaX { get; private set; }
    public double SonDeltaY { get; private set; }

    public HareketliPlatform(double x, double y, double genislik, double yukseklik,
        double minX, double maxX, double minY, double maxY, double hizX, double hizY)
        : base(x, y, genislik, yukseklik)
    {
        MinX = minX;
        MaxX = maxX;
        MinY = minY;
        MaxY = maxY;
        HizX = hizX;
        HizY = hizY;
    }

    public void Guncelle()
    {
        double eskiX = X;
        double eskiY = Y;

        X += HizX;
        if (X <= MinX || X >= MaxX) HizX = -HizX;

        Y += HizY;
        if (Y <= MinY || Y >= MaxY) HizY = -HizY;

        SonDeltaX = X - eskiX;
        SonDeltaY = Y - eskiY;
    }
}

public class Tehlike
{
    public Rect Alan { get; }
    public bool LavMi { get; }

    public Tehlike(double x, double y, double genislik, double yukseklik, bool lavMi = false)
    {
        Alan = new Rect(x, y, genislik, yukseklik);
        LavMi = lavMi;
    }
}

public class BolumVerisi
{
    public int Numara { get; set; }
    public string Ad { get; set; } = "";
    public string Ipucu { get; set; } = "";
    public Point Baslangic { get; set; }
    public Rect Portal { get; set; }
    public List<Platform> Platformlar { get; set; } = new();
    public List<HareketliPlatform> HareketliPlatformlar { get; set; } = new();
    public List<Tehlike> Tehlikeler { get; set; } = new();
}

public static class BolumYoneticisi
{
    public const int ToplamBolum = 10;

    public static BolumVerisi BolumGetir(int bolumNo)
    {
        return bolumNo switch
        {
            1 => new BolumVerisi
            {
                Numara = 1,
                Ad = "Başlangıç Adımları",
                Ipucu = "A/D ile hareket et, W veya SPACE ile zıplayarak yeşil portala ulaş.",
                Baslangic = new Point(50, 464),
                Portal = new Rect(805, 130, 36, 60),
                Platformlar =
                {
                    new(0, 500, 900, 40),
                    new(200, 420, 140, 20),
                    new(400, 340, 140, 20),
                    new(600, 260, 140, 20),
                    new(760, 190, 120, 20)
                }
            },
            2 => new BolumVerisi
            {
                Numara = 2,
                Ad = "Lav Çukurları",
                Ipucu = "Kırmızı lav zeminine düşmeden adalar üzerinden karşıya geç.",
                Baslangic = new Point(40, 464),
                Portal = new Rect(805, 240, 36, 60),
                Platformlar =
                {
                    new(0, 500, 180, 40),
                    new(240, 450, 110, 20),
                    new(420, 400, 110, 20),
                    new(600, 350, 110, 20),
                    new(760, 300, 120, 20)
                },
                Tehlikeler = { new(180, 520, 720, 20, true) }
            },
            3 => new BolumVerisi
            {
                Numara = 3,
                Ad = "Alçak Dikenli Tünel",
                Ipucu = "S tuşuna basılı tutarak eğil ve tavandaki dikenlerin altından geç!",
                Baslangic = new Point(40, 464),
                Portal = new Rect(780, 360, 36, 60),
                Platformlar =
                {
                    new(0, 500, 900, 40),
                    new(240, 320, 360, 136),
                    new(690, 420, 170, 20)
                },
                Tehlikeler = { new(250, 456, 340, 14) }
            },
            4 => new BolumVerisi
            {
                Numara = 4,
                Ad = "Hareketli Platformlar",
                Ipucu = "Yatay ve dikey hareket eden platformların zamanlamasını yakala.",
                Baslangic = new Point(30, 464),
                Portal = new Rect(805, 170, 36, 60),
                Platformlar =
                {
                    new(0, 500, 150, 40),
                    new(490, 390, 90, 20),
                    new(760, 230, 120, 20)
                },
                HareketliPlatformlar =
                {
                    new(180, 440, 110, 18, 170, 360, 440, 440, 2.2, 0),
                    new(620, 380, 110, 18, 620, 620, 230, 410, 0, -2.0)
                },
                Tehlikeler = { new(150, 520, 750, 20, true) }
            },
            5 => new BolumVerisi
            {
                Numara = 5,
                Ad = "Zikzak Kule",
                Ipucu = "Sağ ve sol basamakları kullanarak kuleyi tırman.",
                Baslangic = new Point(50, 464),
                Portal = new Rect(780, 100, 36, 60),
                Platformlar =
                {
                    new(0, 500, 900, 40),
                    new(100, 400, 150, 20),
                    new(330, 320, 150, 20),
                    new(100, 240, 150, 20),
                    new(330, 160, 150, 20),
                    new(580, 160, 260, 20)
                },
                Tehlikeler = { new(300, 486, 320, 14) }
            },
            6 => new BolumVerisi
            {
                Numara = 6,
                Ad = "Hızlı İniş",
                Ipucu = "Havadayken S tuşuna basarak hızla aşağı in ve tavan dikenlerinden kaçın.",
                Baslangic = new Point(40, 144),
                Portal = new Rect(790, 360, 36, 60),
                Platformlar =
                {
                    new(0, 180, 160, 20),
                    new(200, 260, 140, 20),
                    new(410, 340, 140, 20),
                    new(620, 420, 240, 20)
                },
                Tehlikeler =
                {
                    new(0, 520, 900, 20, true),
                    new(200, 115, 140, 16),
                    new(410, 195, 140, 16),
                    new(620, 275, 140, 16)
                }
            },
            7 => new BolumVerisi
            {
                Numara = 7,
                Ad = "Zamanlama Köprüsü",
                Ipucu = "Orta adadaki dikenden zıplayıp ikinci hareketli platforma atla.",
                Baslangic = new Point(30, 424),
                Portal = new Rect(810, 250, 36, 60),
                Platformlar =
                {
                    new(0, 460, 120, 80),
                    new(380, 420, 120, 20),
                    new(770, 310, 110, 20)
                },
                HareketliPlatformlar =
                {
                    new(150, 430, 95, 18, 140, 275, 430, 430, 2.5, 0),
                    new(530, 370, 95, 18, 520, 665, 370, 370, -2.6, 0)
                },
                Tehlikeler =
                {
                    new(120, 520, 780, 20, true),
                    new(430, 404, 20, 16)
                }
            },
            8 => new BolumVerisi
            {
                Numara = 8,
                Ad = "Dar Adalar ve Geçit",
                Ipucu = "Küçük basamaklardan geçip S tuşuyla alçak tüneli aş.",
                Baslangic = new Point(30, 464),
                Portal = new Rect(810, 260, 36, 60),
                Platformlar =
                {
                    new(0, 500, 120, 40),
                    new(180, 440, 75, 20),
                    new(310, 380, 75, 20),
                    new(440, 380, 280, 20),
                    new(480, 250, 200, 86),
                    new(770, 320, 110, 20)
                },
                Tehlikeler =
                {
                    new(120, 520, 780, 20, true),
                    new(490, 336, 180, 14)
                }
            },
            9 => new BolumVerisi
            {
                Numara = 9,
                Ad = "Asansör ve Tuzaklar",
                Ipucu = "Dikey asansörle yukarı çık, dikenli köprüyü geçip alt platforma in.",
                Baslangic = new Point(30, 464),
                Portal = new Rect(812, 200, 36, 60),
                Platformlar =
                {
                    new(0, 500, 140, 40),
                    new(320, 210, 220, 20),
                    new(780, 260, 100, 20)
                },
                HareketliPlatformlar =
                {
                    new(180, 460, 90, 18, 180, 180, 210, 470, 0, -2.5),
                    new(580, 340, 100, 18, 570, 700, 340, 340, 2.4, 0)
                },
                Tehlikeler =
                {
                    new(140, 520, 760, 20, true),
                    new(380, 194, 20, 16),
                    new(470, 194, 20, 16)
                }
            },
            _ => new BolumVerisi
            {
                Numara = 10,
                Ad = "Büyük Final",
                Ipucu = "Tüm becerilerini birleştir: Hareketli platform, S ile eğilme ve son asansör!",
                Baslangic = new Point(30, 464),
                Portal = new Rect(800, 110, 36, 60),
                Platformlar =
                {
                    new(0, 500, 130, 40),
                    new(360, 400, 230, 20),
                    new(400, 280, 150, 76),
                    new(750, 170, 130, 20)
                },
                HareketliPlatformlar =
                {
                    new(160, 440, 85, 18, 150, 265, 440, 440, 2.7, 0),
                    new(630, 400, 85, 18, 630, 630, 170, 410, 0, -2.7)
                },
                Tehlikeler =
                {
                    new(130, 520, 770, 20, true),
                    new(405, 356, 140, 14)
                }
            }
        };
    }
}